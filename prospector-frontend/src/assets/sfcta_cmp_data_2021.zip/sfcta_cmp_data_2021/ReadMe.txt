San Francisco's Congestion Management Program (CMP) Data
  prepared by San Francisco County Transportation Authority (SFCTA)

* For more information about CMP visit https://www.sfcta.org/projects/congestion-management-program
* This download package consists of data collected biennially as a part of CMP
* Here is a list of files in the package in addition to this readme file:
  - "cmp_roadway_segments.zip" contains an ArcGIS shapefile of CMP roadway segments monitored
  - "sfcta_cmp_data_export.csv" is a comma-separated file containing all historic congestion-related data available on the CMP segments
  - "CMP_data_dictionary.xlsx" provides a description of the columns in sfcta_cmp_data_export.csv
  - "aggregate_cmp_data.xlsx" provides aggregate metrics for CMP network as a whole
  
Please feel to email data@sfcta.org to obtain more information about this dataset.