San Francisco's Congestion Management Program (CMP) Data
  prepared by San Francisco County Transportation Authority (SFCTA)

* For more information about CMP visit http://www.sfcta.org/congestion-management
* This download package consists of data collected biennially as a part of CMP
* There are two files in package in addition to this readme file:
  - "cmp_roadway_segments.zip" contains an ArcGIS shapefile of CMP roadway segments monitored
  - "sfcta_cmp_data_export.csv" is a comma-separated file containing all historic congestion-related data available on the CMP segments
  
Please feel to email data@sfcta.org to obtain more information about this dataset.